package com.example.submission_projek_akhir_flutter_pemula

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
